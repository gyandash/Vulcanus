# src/utils/helper.py
# This file can be used for general utility functions as needed in the future.
# No diagram-related utilities are needed here anymore as DiagramRenderer is self-contained.